package com.xiaolinsong.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xiaolinsong.mvc.Information;

@Controller
@RequestMapping("/information")
public class InformationController{
	
	@RequestMapping("/showPersonalForm")
	public String showPersonalForm(Model theModel){
		
		// create a student object
		Information theInformation = new Information();
		// add student object to the model
		theModel.addAttribute("pInformation", theInformation);
		
		return "personal-information-form";
	}
	
	@RequestMapping("/processPersonalForm")
	public String processPersonalForm(@ModelAttribute("pInformation") Information theInformation){
		
		// log the input data
		System.out.println("thePersonalInforamtion: " + theInformation.getFname() +" " + theInformation.getLname());
	
		return"information-form-confirmation";
	}
	
	
}